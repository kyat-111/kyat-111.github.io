#!bin/bash
while true
do
	cd /home/takuya/Desktop/blender
	./blender --background --python /home/takuya/Desktop/sample/server.py
done


