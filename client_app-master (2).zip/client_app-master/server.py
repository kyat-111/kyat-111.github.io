import bpy
import socket

ip_address = '160.251.53.35)'
port = 7010
buffer_size = 1024

#desktop_path = "C:/Users/apapa/Desktop"
desktop_path = "/home/takuya/Desktop"
client_folder_path = desktop_path + "/sample/flask/app"
server_folder_path = desktop_path + "/sample"

# 3Dデータ生成メソッド
def blendergen():
    # 初期データの削除
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    # PLYインポート
    bpy.ops.import_mesh.ply(filepath=server_folder_path+"/cussion.ply")
    # スムースシェード適用
    bpy.ops.object.shade_smooth()
    # スケール変更
    # bpy.ops.transform.resize(value=(z / zz, 1, x / xx))
    # フォルダ作成
    # os.makedirs(desktop_path+"\\automatic\\export\\"+"drape", exist_ok=True)
    # テクスチャマッピング
    mat = bpy.data.materials.new('MATERIAL')
    mat.use_nodes = True
    bsdf = mat.node_tree.nodes["Principled BSDF"]
    # baseColor
    texImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
    texImage.image = bpy.data.images.load(filepath=client_folder_path+"/sample.png")
    mat.node_tree.links.new(bsdf.inputs['Base Color'], texImage.outputs['Color'])
    # normalMap
    # normalMap = mat.node_tree.nodes.new("ShaderNodeNormalMap")
    # mat.node_tree.links.new(bsdf.inputs['Normal'], normalMap.outputs['Normal'])
    # nmImage = mat.node_tree.nodes.new('ShaderNodeTexImage')
    # nmImage.image = bpy.data.images.load(filepath=socket_server_path + "/ex_texture/" + "normal_" + image_path)
    # bpy.data.images["normal_" + image_path].colorspace_settings.name = 'Non-Color'
    # mat.node_tree.links.new(normalMap.inputs['Color'], nmImage.outputs['Color'])
    # alpha value
    #if a == "lace":
    #   mat.blend_method = 'BLEND'
    #   bsdf.inputs[19].default_value = 0.4
    # テクスチャ適用
    bpy.context.object.data.materials.append(mat)
    # glbエクスポート
    bpy.ops.export_scene.gltf(filepath=client_folder_path+"/static/cussion.glb")
    # bpy.ops.export_scene.gltf(filepath=socket_server_path+"/ex_blender/"+a+"_"+b+"_"+str(x)+"_"+str(z)+".glb")

# Socketの作成
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind((ip_address, port))
s.listen(1)

# クライアントからの要求を待つ
while True:
    # 要求があれば接続
    conn, addr = s.accept()
    receive = conn.recv(buffer_size)
    print(receive)
    blendergen()
    conn.sendall(b'complete')
    conn.close()