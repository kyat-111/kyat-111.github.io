from flask import *
import socket
import base64
from PIL import Image,ImageFile 
from io import BytesIO

ip_address = '160.251.53.35)'
port = 7010
buffer_size = 1024
link = "https://garnet-oid.com/static/cussion.glb"

app = Flask(__name__)

@app.route('/')
def index():
    
    return render_template('index.html')

@app.route('/output', methods=['POST'])
def output():
    data_all = bytes()
    # 画像データの取得
    tmp = request.form['img']
    decode_data = base64.b64decode( tmp.split(',')[1] )
    dec_img  = Image.open(BytesIO(decode_data))
    dec_img.save('sample.png')
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        # サーバーに接続を要求する
        s.connect((ip_address, port))
        # データを送信する
        s.sendall(b'send server')
        # サーバーからのデータを受信
        data = s.recv(buffer_size)
            
    return render_template("output.html",link=link)

if __name__ == "__main__":
    app.run(host='0.0.0.0')