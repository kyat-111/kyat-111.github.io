#!bin/bash
while true
do
	cd /home/takuya/Desktop/blender-2.93.0
	./blender --background --python /home/takuya/Desktop/socket_server/server.py
done


